#!/bin/bash
mono SuperSocket.SocketService.exe -c $1 $2