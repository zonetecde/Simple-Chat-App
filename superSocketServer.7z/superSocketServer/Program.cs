﻿using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Command;
using SuperSocket.SocketBase.Protocol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperSocket;
using SuperSocket.WebSocket;

namespace superSocketServer
{
    namespace superSocketServer
    {
        class Program
        {
            static AppServer appServer { get; set; }
            static void Main(string[] args)
            {
                appServer = new AppServer();


                //Setup the appServer
                if (!appServer.Setup(48082))//Setup with listening port
                {
                    Console.WriteLine("Failed to setup!");
                    Console.ReadKey();
                    return;
                }

                //Try to start the appServer
                if (!appServer.Start())
                {
                    Console.WriteLine("Failed to start!");
                    Console.ReadKey();
                    return;
                }


                Console.WriteLine("The server started successfully, press key'q' to stop it!");

                //1.
                appServer.NewSessionConnected += new SessionHandler<AppSession>(appServer_NewSessionConnected);
                appServer.SessionClosed += appServer_NewSessionClosed;

                //2.
                appServer.NewRequestReceived += new RequestHandler<AppSession, StringRequestInfo>(appServer_NewRequestReceived);

                while (Console.ReadKey().KeyChar != 'q')
                {
                    Console.WriteLine();
                    continue;
                }

                //Stop the appServer
                appServer.Stop();

                Console.WriteLine("The server was stopped!");
                Console.ReadKey();
            }

            //1.
            static void appServer_NewSessionConnected(AppSession session)
            {
                Console.WriteLine($"The server got the connection from the client successfully");

                var count = appServer.GetAllSessions().Count();
                Console.WriteLine("~~" + count);

                session.Send("You are connected");
            }

            static void appServer_NewSessionClosed(AppSession session, CloseReason aaa)
            {
                Console.WriteLine($"The server loses the connection from the client" + session.SessionID + aaa.ToString());
                var count = appServer.GetAllSessions().Count();
                Console.WriteLine(count);
            }

            //2.
            static void appServer_NewRequestReceived(AppSession session, StringRequestInfo requestInfo)
            {
                Console.WriteLine(DateTime.Now.ToString() + " - " + session.SessionID + " - " + requestInfo.Key + " " + requestInfo.Body);
                //session.Send(requestInfo.Key);

                foreach (var u in appServer.GetAllSessions())
                {
                    u.Send(requestInfo.Key + " " + requestInfo.Body);
                }
            }



        }

        public class ChatSession : WebSocketSession
        {
            public string Name { get; set; }
        }
    }

    public class ADD : CommandBase<AppSession, StringRequestInfo>
    {
        public override void ExecuteCommand(AppSession session, StringRequestInfo requestInfo)
        {
            session.Send(requestInfo.Parameters.Select(p => int.Parse(p)).Sum().ToString());
        }
    }
}